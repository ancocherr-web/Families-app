import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:geolocator/geolocator.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'db.dart';

const navy = Color(0xFF0B1F5C);
const royal = Color(0xFF1A3A9E);
const govs = ['بغداد','نينوى','البصرة','ذي قار','الأنبار','أربيل','السليمانية','دهوك','كركوك','ديالى','صلاح الدين','بابل','كربلاء','النجف','واسط','ميسان','المثنى','القادسية'];
const edus = ['أمي','يقرأ ويكتب','ابتدائية','متوسطة','إعدادية','دبلوم','بكالوريوس','ماجستير','دكتوراه'];
const rels = ['زوجة','ابن','ابنة','أب','أم','أخ','أخت','آخر'];
const reqs = ['خدمة عامة','تقديم طلب','مساعدة خدمية','أخرى'];

void go(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute(builder: (_) => w));
void snack(BuildContext c, String m) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));
Widget tf(TextEditingController c, String l, {TextInputType? t, int lines = 1, bool obscure = false}) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextField(controller: c, keyboardType: t, maxLines: lines, obscureText: obscure, decoration: InputDecoration(labelText: l)));
Widget dd(String l, String? v, List<String> items, ValueChanged<String?> f) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: DropdownButtonFormField<String>(value: v, decoration: InputDecoration(labelText: l), items: items.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: f));

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
        title: 'نظام إدارة ودعم العوائل والخدمات',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: royal, primary: royal),
          scaffoldBackgroundColor: const Color(0xFFF2F5FC),
          appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
          inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), filled: true, fillColor: Colors.white),
        ),
        home: const Splash(),
      );
}

// ---------------- Splash ----------------
class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashS();
}

class _SplashS extends State<Splash> with SingleTickerProviderStateMixin {
  late final AnimationController a = AnimationController(vsync: this, duration: const Duration(seconds: 3))
    ..forward()
    ..addStatusListener((s) {
      if (s == AnimationStatus.completed && mounted) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Login()));
      }
    });
  @override
  void dispose() { a.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext c) => Scaffold(
        backgroundColor: navy,
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(color: Colors.white.withOpacity(.1), shape: BoxShape.circle),
              child: const Icon(Icons.family_restroom, size: 80, color: Colors.white),
            ),
            const SizedBox(height: 24),
            const Text('نظام إدارة بيانات العوائل', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 32),
            SizedBox(
              width: 220,
              child: AnimatedBuilder(
                animation: a,
                builder: (_, __) => ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(value: a.value, minHeight: 8, backgroundColor: Colors.white24, color: Colors.lightBlueAccent),
                ),
              ),
            ),
          ]),
        ),
      );
}

// ---------------- Login ----------------
class Login extends StatefulWidget {
  const Login({super.key});
  @override
  State<Login> createState() => _LoginS();
}

class _LoginS extends State<Login> {
  final u = TextEditingController(), p = TextEditingController();
  Future<void> doLogin() async {
    if (await DB.login(u.text.trim(), p.text)) {
      if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Home()));
    } else if (mounted) {
      snack(context, 'بيانات الدخول غير صحيحة');
    }
  }
  @override
  Widget build(BuildContext c) => Scaffold(
        backgroundColor: navy,
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.family_restroom, size: 56, color: royal),
                  const SizedBox(height: 8),
                  const Text('تسجيل الدخول', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: navy)),
                  const SizedBox(height: 20),
                  tf(u, 'اسم المستخدم / رقم الهاتف'),
                  tf(p, 'كلمة المرور', obscure: true),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: FilledButton(onPressed: doLogin, style: FilledButton.styleFrom(backgroundColor: royal), child: const Text('دخول')),
                  ),
                  const SizedBox(height: 8),
                  const Text('الافتراضي: admin / admin123', style: TextStyle(color: Colors.grey, fontSize: 12)),
                ]),
              ),
            ),
          ),
        ),
      );
}

// ---------------- Dashboard ----------------
class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeS();
}

class _HomeS extends State<Home> {
  Map<String, int> s = {};
  final q = TextEditingController();
  Future<void> load() async { final r = await DB.stats(); if (mounted) setState(() => s = r); }
  @override
  void initState() { super.initState(); load(); }
  Future<void> open(Widget w) async { await Navigator.push(context, MaterialPageRoute(builder: (_) => w)); load(); }

  Widget stat(String t, String k, IconData i, Color col) => InkWell(
        onTap: () => open(const FamilyList()),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: col, borderRadius: BorderRadius.circular(18)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Icon(i, color: Colors.white, size: 30),
            Text('${s[k] ?? 0}', style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)),
            Text(t, style: const TextStyle(color: Colors.white70)),
          ]),
        ),
      );

  Widget tile(String t, IconData i, Widget w) => Card(
        child: ListTile(leading: Icon(i, color: royal), title: Text(t), trailing: const Icon(Icons.chevron_left), onTap: () => open(w)),
      );

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('لوحة التحكم')),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: royal, foregroundColor: Colors.white,
          onPressed: () => open(const Register()),
          icon: const Icon(Icons.person_add), label: const Text('تسجيل عائلة'),
        ),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          TextField(
            controller: q,
            textInputAction: TextInputAction.search,
            onSubmitted: (v) => open(FamilyList(query: v)),
            decoration: InputDecoration(hintText: 'بحث بالاسم أو الرقم الوطني أو بطاقة الناخب', prefixIcon: const Icon(Icons.search), suffixIcon: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => open(FamilyList(query: q.text)))),
          ),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.3,
            children: [
              stat('إجمالي العوائل', 'families', Icons.home, royal),
              stat('إجمالي الأفراد', 'people', Icons.groups, const Color(0xFF2E5BD8)),
              stat('عدد الطلبات', 'requests', Icons.assignment, const Color(0xFF0E7490)),
              stat('الخدمات العامة', 'services', Icons.volunteer_activism, const Color(0xFF3730A3)),
            ],
          ),
          const SizedBox(height: 16),
          const Text('الوصول السريع', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: navy)),
          tile('عرض كافة العوائل والطلبات', Icons.list_alt, const FamilyList()),
          tile('التقارير', Icons.bar_chart, const Reports()),
          tile('إدارة المستخدمين', Icons.manage_accounts, const Users()),
          tile('الإعدادات والنسخ الاحتياطي', Icons.settings, const Settings()),
          const SizedBox(height: 70),
        ]),
      );
}

// ---------------- Family list / details ----------------
class FamilyList extends StatefulWidget {
  final String query;
  const FamilyList({super.key, this.query = ''});
  @override
  State<FamilyList> createState() => _FamilyListS();
}

class _FamilyListS extends State<FamilyList> {
  late Future<List<Map<String, dynamic>>> f = DB.search(widget.query);
  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: Text(widget.query.isEmpty ? 'كافة العوائل والطلبات' : 'نتائج البحث')),
        body: FutureBuilder<List<Map<String, dynamic>>>(
          future: f,
          builder: (_, snap) {
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final l = snap.data!;
            if (l.isEmpty) return const Center(child: Text('لا توجد نتائج'));
            return ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: l.length,
              itemBuilder: (_, i) => Card(
                child: ListTile(
                  leading: const CircleAvatar(backgroundColor: royal, child: Icon(Icons.person, color: Colors.white)),
                  title: Text(l[i]['name'] ?? ''),
                  subtitle: Text('${l[i]['governorate'] ?? ''} • ${l[i]['request_type'] ?? ''}'),
                  onTap: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => FamilyDetail(l[i]))); setState(() => f = DB.search(widget.query)); },
                ),
              ),
            );
          },
        ),
      );
}

class FamilyDetail extends StatelessWidget {
  final Map<String, dynamic> f;
  const FamilyDetail(this.f, {super.key});
  Widget row(String k, dynamic v) => ListTile(dense: true, title: Text(k, style: const TextStyle(color: Colors.grey)), subtitle: Text('${v ?? '-'}', style: const TextStyle(fontSize: 16)));
  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('تفاصيل العائلة'), actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () async {
              final ok = await showDialog<bool>(context: c, builder: (_) => AlertDialog(title: const Text('حذف العائلة؟'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')), TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('حذف'))]));
              if (ok == true) { await DB.deleteFamily(f['id']); if (c.mounted) Navigator.pop(c); }
            },
          )
        ]),
        body: ListView(children: [
          row('الاسم الرباعي', f['name']), row('الهاتف', f['phone']), row('الرقم الوطني', f['national_id']), row('بطاقة الناخب', f['voter_id']),
          row('المحافظة', f['governorate']), row('القضاء/الناحية', f['district']),
          row('الموقع GPS', f['lat'] == null ? '-' : '${f['lat']}, ${f['lng']}'),
          row('الحالة الوظيفية', f['employed'] == 1 ? 'موظف (${f['job_type']})' : 'غير موظف'),
          row('الشهادة', f['education']), row('نوع الطلب/الخدمة', f['request_type']), row('ملاحظات', f['notes']),
          const Divider(),
          const Padding(padding: EdgeInsets.all(12), child: Text('أفراد الأسرة', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
          FutureBuilder<List<Map<String, dynamic>>>(
            future: DB.members(f['id']),
            builder: (_, s) => Column(children: (s.data ?? []).map((m) => ListTile(title: Text(m['name'] ?? ''), subtitle: Text('${m['relation']} • ${m['age']} سنة • ${m['education'] ?? ''}\n${m['details'] ?? ''}'))).toList()),
          ),
        ]),
      );
}

// ---------------- Registration (stepper) ----------------
class Register extends StatefulWidget {
  const Register({super.key});
  @override
  State<Register> createState() => _RegS();
}

class _RegS extends State<Register> {
  int step = 0;
  String? gov, jobType, req, edu;
  bool employed = false;
  double? lat, lng;
  final district = TextEditingController(), name = TextEditingController(), phone = TextEditingController(),
      nid = TextEditingController(), vid = TextEditingController(), notes = TextEditingController();
  final members = <Map<String, dynamic>>[];

  Future<void> gps() async {
    try {
      var p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
      if (p == LocationPermission.denied || p == LocationPermission.deniedForever) { if (mounted) snack(context, 'تم رفض إذن الموقع'); return; }
      final pos = await Geolocator.getCurrentPosition();
      setState(() { lat = pos.latitude; lng = pos.longitude; });
    } catch (_) { if (mounted) snack(context, 'تعذر تحديد الموقع'); }
  }

  Future<void> addMember() async {
    final n = TextEditingController(), age = TextEditingController(), det = TextEditingController();
    String? rel, ed;
    final m = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: const Text('إضافة فرد'),
          content: SingleChildScrollView(child: Column(children: [
            tf(n, 'الاسم الكامل'),
            dd('صلة القرابة', rel, rels, (v) => set(() => rel = v)),
            tf(age, 'العمر', t: TextInputType.number),
            dd('الشهادة / المستوى الدراسي', ed, edus, (v) => set(() => ed = v)),
            tf(det, 'تفاصيل خاصة', lines: 2),
          ])),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () {
                if (n.text.trim().isEmpty) return;
                Navigator.pop(ctx, {'name': n.text.trim(), 'relation': rel, 'age': int.tryParse(age.text) ?? 0, 'education': ed, 'details': det.text.trim()});
              },
              child: const Text('إضافة'),
            ),
          ],
        ),
      ),
    );
    if (m != null) setState(() => members.add(m));
  }

  Future<void> save() async {
    await DB.saveFamily({
      'governorate': gov, 'district': district.text.trim(), 'lat': lat, 'lng': lng, 'name': name.text.trim(),
      'phone': phone.text.trim(), 'national_id': nid.text.trim(), 'voter_id': vid.text.trim(),
      'employed': employed ? 1 : 0, 'job_type': employed ? jobType : null, 'education': edu,
      'request_type': req, 'notes': notes.text.trim(),
    }, members);
    if (mounted) { snack(context, 'تم حفظ البيانات'); Navigator.pop(context); }
  }

  bool valid() {
    if (step == 0 && gov == null) { snack(context, 'اختر المحافظة'); return false; }
    if (step == 1 && name.text.trim().isEmpty) { snack(context, 'أدخل اسم رب الأسرة'); return false; }
    if (step == 3 && req == null) { snack(context, 'اختر نوع الطلب'); return false; }
    return true;
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('تسجيل عائلة جديدة')),
        body: Stepper(
          currentStep: step,
          onStepTapped: (i) => setState(() => step = i),
          onStepCancel: () { if (step > 0) setState(() => step--); },
          onStepContinue: () { if (!valid()) return; if (step < 3) { setState(() => step++); } else { save(); } },
          controlsBuilder: (_, d) => Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Row(children: [
              FilledButton(onPressed: d.onStepContinue, child: Text(step == 3 ? 'حفظ' : 'التالي')),
              const SizedBox(width: 8),
              if (step > 0) TextButton(onPressed: d.onStepCancel, child: const Text('السابق')),
            ]),
          ),
          steps: [
            Step(title: const Text('بيانات الموقع'), isActive: step >= 0, content: Column(children: [
              dd('المحافظة', gov, govs, (v) => setState(() => gov = v)),
              tf(district, 'القضاء / الناحية'),
              OutlinedButton.icon(onPressed: gps, icon: const Icon(Icons.my_location), label: Text(lat == null ? 'تحديد الموقع عبر GPS' : 'تم: ${lat!.toStringAsFixed(5)}, ${lng!.toStringAsFixed(5)}')),
            ])),
            Step(title: const Text('رب الأسرة والوظيفة'), isActive: step >= 1, content: Column(children: [
              tf(name, 'الاسم الرباعي'),
              tf(phone, 'رقم الهاتف', t: TextInputType.phone),
              tf(nid, 'رقم البطاقة الوطنية', t: TextInputType.number),
              tf(vid, 'رقم بطاقة الناخب', t: TextInputType.number),
              dd('الحالة الوظيفية', employed ? 'موظف' : 'غير موظف', ['موظف', 'غير موظف'], (v) => setState(() => employed = v == 'موظف')),
              if (employed) dd('نوع الوظيفة', jobType, ['مدني', 'عسكري'], (v) => setState(() => jobType = v)),
              dd('الشهادة / المستوى الدراسي', edu, edus, (v) => setState(() => edu = v)),
            ])),
            Step(title: const Text('أفراد الأسرة'), isActive: step >= 2, content: Column(children: [
              Align(alignment: Alignment.centerRight, child: Text('عدد الأفراد المستحقين: ${members.length}', style: const TextStyle(fontWeight: FontWeight.bold))),
              ...members.asMap().entries.map((e) => Card(child: ListTile(
                    title: Text(e.value['name']),
                    subtitle: Text('${e.value['relation'] ?? ''} • ${e.value['age']} سنة • ${e.value['education'] ?? ''}'),
                    trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => setState(() => members.removeAt(e.key))),
                  ))),
              OutlinedButton.icon(onPressed: addMember, icon: const Icon(Icons.add), label: const Text('إضافة فرد')),
            ])),
            Step(title: const Text('نوع الطلب والخدمة'), isActive: step >= 3, content: Column(children: [
              dd('نوع الطلب / الخدمة', req, reqs, (v) => setState(() => req = v)),
              tf(notes, 'ملاحظات', lines: 3),
            ])),
          ],
        ),
      );
}

// ---------------- Reports ----------------
class Reports extends StatelessWidget {
  const Reports({super.key});
  Widget sec(String t, String col) => FutureBuilder<List<Map<String, dynamic>>>(
        future: DB.groupCount(col),
        builder: (_, s) => Card(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Padding(padding: const EdgeInsets.all(12), child: Text(t, style: const TextStyle(fontWeight: FontWeight.bold, color: navy))),
            ...(s.data ?? []).map((r) => ListTile(dense: true, title: Text('${r['k'] ?? 'غير محدد'}'), trailing: CircleAvatar(radius: 14, backgroundColor: royal, child: Text('${r['n']}', style: const TextStyle(color: Colors.white, fontSize: 12))))),
          ]),
        ),
      );
  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('التقارير')),
        body: ListView(padding: const EdgeInsets.all(12), children: [sec('العوائل حسب المحافظة', 'governorate'), sec('حسب نوع الطلب', 'request_type'), sec('حسب الشهادة', 'education')]),
      );
}

// ---------------- Users ----------------
class Users extends StatefulWidget {
  const Users({super.key});
  @override
  State<Users> createState() => _UsersS();
}

class _UsersS extends State<Users> {
  Future<void> add() async {
    final u = TextEditingController(), p = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('مستخدم جديد'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [tf(u, 'اسم المستخدم / الهاتف'), tf(p, 'كلمة المرور', obscure: true)]),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إضافة'))],
      ),
    );
    if (ok == true && u.text.trim().isNotEmpty && p.text.isNotEmpty) {
      try { await DB.addUser(u.text.trim(), p.text, 'مستخدم'); } catch (_) { if (mounted) snack(context, 'المستخدم موجود مسبقاً'); }
      setState(() {});
    }
  }
  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('إدارة المستخدمين')),
        floatingActionButton: FloatingActionButton(onPressed: add, child: const Icon(Icons.add)),
        body: FutureBuilder<List<Map<String, dynamic>>>(
          future: DB.users(),
          builder: (_, s) => ListView(children: (s.data ?? []).map((u) => ListTile(
                leading: const Icon(Icons.account_circle, color: royal),
                title: Text(u['username']), subtitle: Text(u['role']),
                trailing: u['username'] == 'admin' ? null : IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { await DB.delUser(u['id']); setState(() {}); }),
              )).toList()),
        ),
      );
}

// ---------------- Settings: backup / restore ----------------
class Settings extends StatelessWidget {
  const Settings({super.key});
  Future<void> backup(BuildContext c) async {
    try {
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/families_backup_${DateTime.now().millisecondsSinceEpoch}.json');
      await f.writeAsString(await DB.exportJson());
      await Share.shareXFiles([XFile(f.path)], text: 'نسخة احتياطية - نظام إدارة العوائل');
    } catch (e) { if (c.mounted) snack(c, 'فشل إنشاء النسخة: $e'); }
  }

  Future<void> restore(BuildContext c) async {
    final r = await FilePicker.platform.pickFiles(type: FileType.any);
    final path = r?.files.single.path;
    if (path == null || !c.mounted) return;
    final ok = await showDialog<bool>(
      context: c,
      builder: (ctx) => AlertDialog(
        title: const Text('استعادة نسخة احتياطية'),
        content: const Text('سيتم استبدال كافة البيانات الحالية بمحتوى الملف. هل تريد المتابعة؟'),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('استعادة'))],
      ),
    );
    if (ok != true) return;
    try {
      await DB.restoreJson(await File(path).readAsString());
      if (c.mounted) snack(c, 'تمت استعادة البيانات بنجاح');
    } catch (e) { if (c.mounted) snack(c, 'ملف غير صالح أو تالف'); }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('الإعدادات')),
        body: ListView(padding: const EdgeInsets.all(12), children: [
          Card(child: ListTile(leading: const Icon(Icons.backup, color: royal), title: const Text('إنشاء نسخة احتياطية'), subtitle: const Text('تصدير كل البيانات كملف JSON للحفظ أو المشاركة'), onTap: () => backup(c))),
          Card(child: ListTile(leading: const Icon(Icons.restore, color: royal), title: const Text('استعادة نسخة احتياطية'), subtitle: const Text('اختيار ملف JSON واسترجاع البيانات'), onTap: () => restore(c))),
          Card(child: ListTile(leading: const Icon(Icons.logout, color: royal), title: const Text('تسجيل الخروج'), onTap: () => Navigator.pushAndRemoveUntil(c, MaterialPageRoute(builder: (_) => const Login()), (_) => false))),
        ]),
      );
}
